class TgtgLoginError(Exception):
    pass


class TgtgAPIError(Exception):
    pass
